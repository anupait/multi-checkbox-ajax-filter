-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 15, 2016 at 07:13 PM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `test_multi_sets`()
    DETERMINISTIC
begin
        select user() as first_col;
        select user() as first_col, now() as second_col;
        select user() as first_col, now() as second_col, now() as third_col;
        end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `mobile_phones`
--

CREATE TABLE IF NOT EXISTS `mobile_phones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `samsung` tinyint(1) DEFAULT NULL,
  `iphone` tinyint(1) DEFAULT NULL,
  `htc` tinyint(1) DEFAULT NULL,
  `lg` tinyint(1) DEFAULT NULL,
  `nokia` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `mobile_phones`
--

INSERT INTO `mobile_phones` (`id`, `name`, `price`, `samsung`, `iphone`, `htc`, `lg`, `nokia`) VALUES
(1, 'Samsung Galaxy S 1', 180, 1, 0, 0, 0, 0),
(2, 'Samsung Galaxy S 2', 220, 1, 0, 0, 0, 0),
(3, 'Samsung Galaxy S 3', 300, 1, 0, 0, 0, 0),
(4, 'Samsung Galaxy S 4', 450, 1, 0, 0, 0, 0),
(5, 'Samsung Galaxy S 4 mini', 400, 1, 0, 0, 0, 0),
(6, 'Iphone 3GS', 150, 0, 1, 0, 0, 0),
(7, 'Iphone 4', 200, 0, 1, 0, 0, 0),
(8, 'Iphone 4S', 250, 0, 1, 0, 0, 0),
(9, 'Iphone 5', 300, 0, 1, 0, 0, 0),
(10, 'Iphone 5S', 350, 0, 1, 0, 0, 0),
(11, 'Htc Desire', 150, 0, 0, 1, 0, 0),
(12, 'Htc Desire200', 200, 0, 0, 1, 0, 0),
(13, 'Htc Desire500', 250, 0, 0, 1, 0, 0),
(14, 'Htc One', 400, 0, 0, 1, 0, 0),
(15, 'Htc One mini', 250, 0, 0, 1, 0, 0),
(16, 'Lg Optimus L3', 150, 0, 0, 0, 1, 0),
(17, 'Lg Optimus L5', 250, 0, 0, 0, 1, 0),
(18, 'Lg Optimus L7', 350, 0, 0, 0, 1, 0),
(19, 'Lg Optimus L9', 400, 0, 0, 0, 1, 0),
(20, 'Lg Optimus G2', 450, 0, 0, 0, 1, 0),
(21, 'Nokia 100', 50, 0, 0, 0, 0, 1),
(22, 'Nokia E72', 100, 0, 0, 0, 0, 1),
(23, 'Nokia E6', 150, 0, 0, 0, 0, 1),
(24, 'Nokia Lumia 520', 200, 0, 0, 0, 0, 1),
(25, 'Nokia Lumia 620', 250, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `products` varchar(100) DEFAULT NULL,
  `brands` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `color` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `products`, `brands`, `price`, `color`) VALUES
(1, 'product 1', 'Computer', 'Apple', '10000', '1'),
(2, 'product 2', 'Laptop', 'Apple', '30000', '0'),
(3, 'product 3', 'pendrive', 'Apple', '10000', '0'),
(4, 'product 4', 'Computer', 'Apple', '20000', '0'),
(5, 'product 5', 'Computer', 'hp', '20000', '1'),
(6, 'product 6', 'Laptop', 'Apple', '30000', '0'),
(7, 'product 7', 'Laptop', 'hp', '20000', '0'),
(8, 'product 8', 'pendrive', 'Apple', '10000', '1'),
(9, 'product 9', 'pendrive', 'hp', '20000', '1'),
(10, 'product 10', 'pendrive', 'lenovo', '20000', '1'),
(11, 'product 11', 'Laptop', 'lenovo', '20000', '1'),
(12, 'product 12', 'Computer', 'lenovo', '20000', '1'),
(13, 'product 13', 'Computer', 'Apple', '20000', '0'),
(14, 'product 14', 'Computer', 'Apple', '10000', '1'),
(15, 'product 15', 'Computer', 'Apple', '30000', '0'),
(16, 'product 16', 'Computer', 'Apple', '30000', '1'),
(17, 'product 17', 'Laptop', 'Apple', '20000', '0'),
(18, 'product 18', 'Laptop', 'Apple', '20000', '1'),
(19, 'product 19', 'Laptop', 'Apple', '10000', '0'),
(20, 'product 20', 'Laptop', 'Apple', '10000', '1'),
(21, 'product 21', 'pendrive', 'Apple', '20000', '1'),
(22, 'product 22', 'pendrive', 'Apple', '20000', '1'),
(23, 'product 23', 'pendrive', 'Apple', '30000', '1'),
(24, 'product 24', 'pendrive', 'Apple', '30000', '1'),
(25, 'product 13', 'Computer', 'hp', '20000', '0'),
(26, 'product 14', 'Computer', 'hp', '10000', '1'),
(27, 'product 15', 'Computer', 'hp', '10000', '0'),
(28, 'product 16', 'Computer', 'hp', '30000', '1'),
(29, 'product 25', 'Computer', 'hp', '30000', '1'),
(30, 'product 17', 'Laptop', 'hp', '20000', '0'),
(31, 'product 18', 'Laptop', 'hp', '30000', '1'),
(32, 'product 19', 'Laptop', 'hp', '30000', '0'),
(33, 'product 20', 'Laptop', 'hp', '10000', '1'),
(34, 'product 27', 'Laptop', 'hp', '10000', '1'),
(35, 'product 21', 'pendrive', 'hp', '20000', '1'),
(36, 'product 22', 'pendrive', 'hp', '10000', '1'),
(37, 'product 23', 'pendrive', 'hp', '10000', '1'),
(38, 'product 24', 'pendrive', 'hp', '30000', '1'),
(39, 'product 28', 'pendrive', 'hp', '30000', '1'),
(40, 'product 13', 'Computer', 'lenovo', '20000', '0'),
(41, 'product 14', 'Computer', 'lenovo', '10000', '1'),
(42, 'product 15', 'Computer', 'lenovo', '10000', '0'),
(43, 'product 16', 'Computer', 'lenovo', '30000', '1'),
(44, 'product 25', 'Computer', 'lenovo', '30000', '1'),
(45, 'product 17', 'Laptop', 'lenovo', '20000', '0'),
(46, 'product 18', 'Laptop', 'lenovo', '30000', '1'),
(47, 'product 19', 'Laptop', 'lenovo', '30000', '0'),
(48, 'product 20', 'Laptop', 'lenovo', '10000', '1'),
(49, 'product 27', 'Laptop', 'lenovo', '10000', '1'),
(50, 'product 21', 'pendrive', 'lenovo', '20000', '1'),
(51, 'product 22', 'pendrive', 'lenovo', '10000', '1'),
(52, 'product 23', 'pendrive', 'lenovo', '10000', '1'),
(53, 'product 24', 'pendrive', 'lenovo', '30000', '1'),
(54, 'product 28', 'pendrive', 'lenovo', '30000', '1');

-- --------------------------------------------------------

--
-- Table structure for table `table1`
--

CREATE TABLE IF NOT EXISTS `table1` (
  `id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(111) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `table1`
--

INSERT INTO `table1` (`id`, `name`) VALUES
(1, 'Anoop'),
(2, 'Adarsh'),
(3, 'Anuj'),
(44, 'Rakes'),
(55, 'Santosh'),
(66, 'Ankita');

-- --------------------------------------------------------

--
-- Table structure for table `table2`
--

CREATE TABLE IF NOT EXISTS `table2` (
  `id` int(111) NOT NULL AUTO_INCREMENT,
  `title` varchar(111) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `table2`
--

INSERT INTO `table2` (`id`, `title`) VALUES
(1, 'Rai'),
(2, 'Rai'),
(3, 'Sharma'),
(4, 'Yadav'),
(5, 'Kushawaha'),
(6, 'Panwar');

-- --------------------------------------------------------

--
-- Table structure for table `table3`
--

CREATE TABLE IF NOT EXISTS `table3` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `user_id` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1112 ;

--
-- Dumping data for table `table3`
--

INSERT INTO `table3` (`id`, `user_id`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(5, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(11, 0),
(12, 0),
(13, 0),
(15, 99),
(100, 0),
(999, 0),
(1111, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
